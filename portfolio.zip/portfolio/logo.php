<?php session_start(); ?>


<?php require 'dashboard_header.php'; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="row">

            <div class="col-6">
                <div class="card h-auto">
                    <div class="card-header">
                        <h4>Update Header Logo</h4>
                    </div>
                    <div class="card-body">

                        <?php if(isset($_SESSION["header_logo"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["header_logo"]; ?></div>
                        <?php } unset($_SESSION["header_logo"]) ?>

                        <form action="header_logo_update.php" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="">Image</label>
                                <input type="file" class="form-control" name="header_logo"onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                <div class="mt-3"><img src="uploads/logo/header_logo.png" width="100" id="blah1" alt=""></div>
                                <?php if(isset($_SESSION['extention'])){ ?>
                                    <strong class="text-danger"><?= $_SESSION["extention"]; ?></strong>
                                <?php } unset($_SESSION['extention']) ?>
                            </div>
                            <button type="submit" class="btn btn-primary">Update Logo</button>
                        </form>
                    </div>
                </div>
            </div>            
            <div class="col-6">
                <div class="card h-auto">
                    <div class="card-header">
                        <h4>Update Footer Logo</h4>
                    </div>
                    <div class="card-body">

                         <?php if(isset($_SESSION["footer_logo"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["footer_logo"]; ?></div>
                        <?php } unset($_SESSION["footer_logo"]) ?>
                                    
                        <form action="footer_logo_update.php" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="">Image</label>
                                <input type="file" class="form-control" name="footer_logo" onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                <div class="mt-3"><img src="uploads/logo/footer_logo.png" width="100" id="blah2" alt=""></div>

                                <?php if(isset($_SESSION['extention2'])){ ?>
                                    <strong class="text-danger"><?= $_SESSION["extention2"]; ?></strong>
                                <?php } unset($_SESSION['extention2']) ?>

                            </div>
                            <button type="submit" class="btn btn-primary">Update Logo</button>
                        </form>
                    </div>
                </div>
            </div>            

		</div>
    </div>
</div>
<!--**********************************
            Content body end
***********************************-->

<?php require 'dashboard_footer.php'; ?>