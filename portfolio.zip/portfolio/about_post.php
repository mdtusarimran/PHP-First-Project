<?php 
    session_start();
    require 'db_connect.php';

    $designation = $_POST['designation'];
    $name = $_POST['name'];
    $nickname = $_POST['nickname'];
    $short_description = $_POST['short_description'];
    $image = $_FILES['image'];

    if($image['name'] == ''){
        $update = "UPDATE abouts SET designation='$designation', name='$name', nickname='$nickname', short_description='$short_description' WHERE id=1 ";
        $update_res = mysqli_query($db_connection, $update);
        $_SESSION['update'] = 'About Updated Successfully!';
        header('location:about.php');
    }else{
        $after_explode = explode('.', $image['name']);
        $extension = end($after_explode);
        $allowed_extension = ['jpg', 'png', 'jpeg'];
    
        $select_image = "SELECT * FROM abouts WHERE id=1";
        $select_image_res = mysqli_query($db_connection, $select_image);
        $after_assoc = mysqli_fetch_assoc($select_image_res);

        if(in_array($extension, $allowed_extension)){

            if($image['size'] <= 5000000){
    
                $delete_from = 'uploads/about/'. $after_assoc['image'];
                unlink($delete_from);
                
                $file_name = 'image'.'.'.$extension;
                $new_location = 'uploads/about/'.$file_name;
                move_uploaded_file($image['tmp_name'], $new_location);
    
                $update = "UPDATE abouts SET designation='$designation', name='$name', nickname='$nickname', short_description='$short_description', image='$file_name' WHERE id=1 ";
                $update_res = mysqli_query($db_connection, $update);

                $_SESSION['update'] = 'About Updated Successfully!';
                header('location:about.php');
                
    
            }else{
                $_SESSION['extention'] = 'Maximum Image Size 512kb';
                header('location:about.php');
            }
    
        }else{
            $_SESSION['extention'] = 'jpg, png or jpeg extention not found!';
            header('location:about.php');
        }

    }






?>