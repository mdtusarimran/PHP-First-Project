<?php

    $hostname = 'localhost';
    $hostuser = 'root';
    $hostpassword = '';
    $dbName = 'iawd-2302';

    $db_connection = mysqli_connect($hostname, $hostuser, $hostpassword, $dbName);

?>