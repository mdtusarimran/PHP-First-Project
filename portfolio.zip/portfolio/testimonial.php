<?php
    session_start();
    require 'db_connect.php';

    $testimonial = "SELECT * FROM testimonials";
    $testimonial_res = mysqli_query($db_connection, $testimonial);
?>

<?php require 'dashboard_header.php'; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="row">
            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        <h4>Testimonial List</h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($_SESSION["delete_testimonial"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["delete_testimonial"]; ?></div>
                        <?php } unset($_SESSION["delete_testimonial"]) ?>

                        <table class="table table-bordered">
                            <tr>
                                <th>SL</th>
                                <th>Name</th>
                                <th>Occupation</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php foreach($testimonial_res as $sl => $testimonial){ ?>
                                <tr>
                                    <td><?= $sl + 1 ?></td>
                                    <td><?= $testimonial['name'] ?></td>
                                    <td><?= $testimonial['occupation'] ?></td>
                                    <td><?= $testimonial['description'] ?></td>
                                    <td><img width="100" src="uploads/testimonial/<?= $testimonial['image'] ?>" alt=""></td>
                                    <td>
                                        <a href="testimonial_status_change.php?id=<?= $testimonial['id'] ?>" class="btn btn-sm btn-<?= $testimonial['status'] == 1? 'success' : 'light' ?>"><?= $testimonial['status'] == 1? 'Active' : 'Deactive' ?></a>
                                    </td>
                                    <td>
                                        <div class="d-flex">
	                                        <a href="delete_testimonial.php?id=<?= $testimonial['id'] ?>" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php }?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card h-auto">
                    <div class="card-header">
                        <h4>Add Testimonial</h4>
                    </div>
                    <div class="card-body">

                        <?php if(isset($_SESSION["testimonial"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["testimonial"]; ?></div>
                        <?php } unset($_SESSION["testimonial"]) ?>

                        <form action="testimonial_post.php" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="name">Name</label>
                                <input type="text" name="name" class="form-control" id="name">
                            </div>
                            <div class="mb-3">
                                <label for="occupation">Occupation</label>
                                <input type="text" name="occupation" class="form-control" id="occupation">
                            </div>
                            <div class="mb-3">
                                <label for="description">Description</label>
                                <textarea name="description" id="description" cols="20" rows="5" class="form-control"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="image">Testimonial Image</label>
                                <input type="file" name="image" class="form-control" id="image">
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Add Testimonial</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>
<!--**********************************
            Content body end
***********************************-->

<?php require 'dashboard_footer.php'; ?>

