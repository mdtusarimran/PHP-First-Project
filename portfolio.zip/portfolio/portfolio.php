<?php
    session_start();
    require 'db_connect.php';

    $portfolio = "SELECT * FROM portfolios";
    $portfolio_res = mysqli_query($db_connection, $portfolio);
?>

<?php require 'dashboard_header.php'; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="row">
            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        <h4>Portfolio List</h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($_SESSION["delete_portfolio"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["delete_portfolio"]; ?></div>
                        <?php } unset($_SESSION["delete_portfolio"]) ?>

                        <table class="table table-bordered">
                            <tr>
                                <th>SL</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Portfolio Image</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php foreach($portfolio_res as $sl => $portfolio){ ?>
                                <tr>
                                    <td><?= $sl + 1 ?></td>
                                    <td><?= $portfolio['title'] ?></td>
                                    <td><?= $portfolio['category'] ?></td>
                                    <td><img width="100" src="uploads/portfolio/<?= $portfolio['image'] ?>" alt=""></td>
                                    <td>
                                        <a href="portfolio_status_change.php?id=<?= $portfolio['id'] ?>" class="btn btn-sm btn-<?= $portfolio['status'] == 1? 'success' : 'light' ?>"><?= $portfolio['status'] == 1? 'Active' : 'Deactive' ?></a>
                                    </td>
                                    <td>
                                        <div class="d-flex">
	                                        <a href="delete_portfolio.php?id=<?= $portfolio['id'] ?>" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php }?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card h-auto">
                    <div class="card-header">
                        <h4>Add Portfolio</h4>
                    </div>
                    <div class="card-body">

                        <?php if(isset($_SESSION["portfolio"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["portfolio"]; ?></div>
                        <?php } unset($_SESSION["portfolio"]) ?>

                        <form action="portfolio_post.php" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="title">Title</label>
                                <input type="text" name="title" class="form-control" id="title">
                            </div>
                            <div class="mb-3">
                                <label for="category">Category</label>
                                <input type="text" name="category" class="form-control" id="category">
                            </div>
                            <div class="mb-3">
                                <label for="image">Portfolio Image</label>
                                <input type="file" name="image" class="form-control" id="image">
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Add Portfolio</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>
<!--**********************************
            Content body end
***********************************-->

<?php require 'dashboard_footer.php'; ?>

