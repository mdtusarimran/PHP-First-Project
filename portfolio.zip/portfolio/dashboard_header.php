<?php
    
    require 'db_connect.php';
    $user_id = $_SESSION['user_id'];
    $user = "SELECT * FROM users WHERE id=$user_id";
    $user_info = mysqli_query($db_connection, $user);
    $after_assoc_user_info = mysqli_fetch_assoc($user_info);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Gymove - Fitness Bootstrap Admin Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="dashboard-asset/images/favicon.png">
	<link rel="stylesheet" href="dashboard-asset/vendor/chartist/css/chartist.min.css">
    <link href="dashboard-asset/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="dashboard-asset/vendor/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="dashboard-asset/css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"/>
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="dashboard.php" class="brand-logo">
                <img width="200" src="dashboard-asset/images/1.png" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="dashboard_bar">
								Dashboard
                            </div>
                        </div>
                        <ul class="navbar-nav header-right">
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="javascript:void(0)" role="button" data-toggle="dropdown">

                                <?php if($after_assoc_user_info['Image'] == null){ ?>
                                    <img src="dashboard-asset/images/profile/17.jpg" width="20" alt=""/>
                                <?php } else{ ?>
                                    <img src="uploads/users_img/<?= $after_assoc_user_info['Image'] ?>" width="20" alt=""/>
                                <?php } ?>


									<div class="header-info">
										<span class="text-black"><strong><?= $after_assoc_user_info['Name'] ?></strong></span>
										<p class="fs-12 mb-0">Super Admin</p>
									</div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="profile.php" class="dropdown-item ai-icon">
                                        <svg id="icon-user1" xmlns="http://www.w3.org/2000/svg" class="text-primary" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                        <span class="ml-2">Profile </span>
                                    </a>
                                    <a href="logout.php" class="dropdown-item ai-icon">
                                        <svg id="icon-logout" xmlns="http://www.w3.org/2000/svg" class="text-danger" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                                        <span class="ml-2">Logout </span>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li>
                        <a href="dashboard.php">
                            <i class="fa-solid fa-house"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                    </li>
                    <li>
                        <a class="has-arrow ai-icon" href="users_list.php">
                            <i class="fa-solid fa-users"></i>
							<span class="nav-text">Users List</span>
						</a>
                    </li>
                    <li>
                        <a class="has-arrow ai-icon" href="logo.php">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Logo</span>
						</a>
                    </li>
                    <li>
                        <a class="has-arrow ai-icon" href="about.php">
                            <i class="fa-regular fa-address-card"></i>
							<span class="nav-text">About Me</span>
						</a>
                    </li>
                    <li>
                        <a class="has-arrow ai-icon" href="expertise.php">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Expertise</span>
						</a>
                    </li>
                    <li>
                        <a href="service.php" class="ai-icon">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Service</span>
						</a>
					</li>
                    <li>
                        <a class="has-arrow ai-icon" href="portfolio.php">
							<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Portfolio</span>
						</a>
                    </li>
                    <li>
                        <a class="has-arrow ai-icon" href="testimonial.php">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Testimonial</span>
						</a>
                    </li>
                    <li>
                        <a class="has-arrow ai-icon" href="contact.php">
                            <i class="fa-solid fa-address-book"></i>
							<span class="nav-text">Contact</span>
						</a>
                    </li>
                </ul>
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->