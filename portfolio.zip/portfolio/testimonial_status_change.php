<?php
    require 'db_connect.php';
    $id = $_GET['id'];

    $select = "SELECT * FROM testimonials WHERE id=$id";
    $select_res = mysqli_query($db_connection, $select);
    $after_assoc = mysqli_fetch_assoc($select_res);

    if($after_assoc['status'] == 1){
        $update = "UPDATE testimonials SET status=0 WHERE id=$id";
        mysqli_query($db_connection, $update);
        header('location:testimonial.php');
    }else{
        $update = "UPDATE testimonials SET status=1 WHERE id=$id";
        mysqli_query($db_connection, $update);
        header('location:testimonial.php');
    }



?>