<?php 
    session_start();
    require 'db_connect.php';
    $id = $_GET['id'];
    
    $delete = "DELETE FROM services WHERE id=$id";
    mysqli_query($db_connection, $delete);
    $_SESSION['delete_service'] = 'Service Deleted Successfully!';
    header('location:service.php');
    

?>