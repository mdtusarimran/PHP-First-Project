<?php
    session_start();
    require 'db_connect.php';

    $about = "SELECT * FROM abouts";
    $about_res = mysqli_query($db_connection, $about);
    $after_assoc_about = mysqli_fetch_assoc($about_res);
?>

<?php require 'dashboard_header.php'; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="row">
            <div class="col-8 m-auto">
                <div class="card">
                    <div class="card-header">
                        <h4>Update About Information</h4>
                    </div>
                    <div class="card-body">

                        <?php if(isset($_SESSION["update"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["update"]; ?></div>
                        <?php } unset($_SESSION["update"]) ?>

                        <form action="about_post.php" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="designation">Designation</label>
                                <input type="text" name="designation" class="form-control" id="designation" value="<?= $after_assoc_about['designation'] ?>">
                            </div>
                            <div class="mb-3">
                                <label for="name">Name</label>
                                <input type="text" name="name" class="form-control" id="name" value="<?= $after_assoc_about['name'] ?>">
                            </div>
                            <div class="mb-3">
                                <label for="nickname">Nick Name</label>
                                <input type="text" name="nickname" class="form-control" id="nickname" value="<?= $after_assoc_about['nickname'] ?>">
                            </div>
                            <div class="mb-3">
                                <label for="short_description">Short Description</label>
                                <textarea name="short_description" class="form-control" id="short_description" cols="20" rows="5"><?= $after_assoc_about['short_description'] ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="designation">Image</label>
                                <input type="file" name="image" class="form-control text-center" id="image" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                                <div class="my-3"><img src="uploads/about/<?= $after_assoc_about['image'] ?>" width="200" id="blah" alt="">
                                </div>

                                <?php if(isset($_SESSION['extention'])){ ?>
                                    <strong class="text-danger"><?= $_SESSION['extention'] ?></strong>
                                <?php } unset($_SESSION['extention']) ?>

                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>
<!--**********************************
            Content body end
***********************************-->

<?php require 'dashboard_footer.php'; ?>

