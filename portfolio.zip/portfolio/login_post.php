<?php 
    session_start();

    require'db_connect.php';

    $email = $_POST['email'];
    $password = $_POST['password'];

    $select = "SELECT COUNT(*) as peyechi FROM users WHERE Email='$email'";
    $select_query = mysqli_query($db_connection, $select);
    $after_assoc = mysqli_fetch_assoc($select_query);

    if($after_assoc['peyechi'] == 1){
        $user = "SELECT * FROM users WHERE Email='$email'";
        $user_query = mysqli_query($db_connection, $user);
        $after_assoc_user = mysqli_fetch_assoc($user_query);
        if(password_verify($password, $after_assoc_user['Password'])){
            $_SESSION['login hoise']="ha";
            $_SESSION['user_id'] = $after_assoc_user['Id'];
            header('location: dashboard.php');
        }else{
            $_SESSION['wrong']="wrong password";
            header('location: login.php');
        }
        
    }else{
        $_SESSION['invalid']="invalid email address";
        header('location: login.php');
    }
?>