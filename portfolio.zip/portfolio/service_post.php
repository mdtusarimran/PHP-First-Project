<?php 
    session_start();
    require 'db_connect.php';

    $title = $_POST['title'];
    $short_description = $_POST['short_description'];

    $insert = "INSERT INTO services(title, short_description)VALUES('$title', '$short_description')";
    mysqli_query($db_connection, $insert);

    $_SESSION['service'] = 'New Service Added!';
    header('location:service.php');


?>