<?php 
    session_start();
    require 'db_connect.php';
    $id = $_GET['id'];
    
    $delete = "DELETE FROM expertises WHERE id=$id";
    mysqli_query($db_connection, $delete);
    $_SESSION['delete_expertise'] = 'Expertise Deleted Successfully!';
    header('location:expertise.php');
    

?>