<?php
    require 'db_connect.php';
    $id = $_GET['id'];

    $select = "SELECT * FROM expertises WHERE id=$id";
    $select_res = mysqli_query($db_connection, $select);
    $after_assoc = mysqli_fetch_assoc($select_res);

    if($after_assoc['status'] == 1){
        $update = "UPDATE expertises SET status=0 WHERE id=$id";
        mysqli_query($db_connection, $update);
        header('location:expertise.php');
    }else{
        $update = "UPDATE expertises SET status=1 WHERE id=$id";
        mysqli_query($db_connection, $update);
        header('location:expertise.php');
    }



?>