<?php 
    session_start();
    require 'db_connect.php';

    $id = $_GET['id'];

    $delete = "DELETE FROM contacts WHERE id=$id";
    mysqli_query($db_connection, $delete);

    $_SESSION['userDelete'] = 'Contact deleted successfully';
    header('location:contact.php');

    

?>