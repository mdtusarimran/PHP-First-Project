<?php 
    session_start();
    require 'db_connect.php';

    $id = $_GET['id'];

    $image = "SELECT * FROM users WHERE Id=$id";
    $image_res = mysqli_query($db_connection, $image);
    $after_assoc = mysqli_fetch_assoc($image_res);
    $delete_from = 'uploads/users_img/'.$after_assoc['Image'];
    unlink($delete_from);
    
    $delete = "DELETE FROM users WHERE Id=$id";
    mysqli_query($db_connection, $delete);

    $_SESSION['userDelete'] = 'user deleted successfully';
    header('location:users_list.php');

    

?>