<?php
    session_start();
    require 'db_connect.php';

    $user_id = $_POST['user_id'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    $after_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);

    if(empty($password)){
        $update = "UPDATE users SET Name='$name' WHERE Id='$user_id'";
        mysqli_query($db_connection, $update);

        $_SESSION['update'] = 'Profile Updated Successfully!';
        header('location:profile.php');
    }else{
        $update = "UPDATE users SET Name='$name', Password='$after_hash' WHERE Id='$user_id'";
        mysqli_query($db_connection, $update);

        $_SESSION['update'] = 'Profile Updated Successfully!';
        header('location:profile.php');
    }

?>