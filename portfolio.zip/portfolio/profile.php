<?php session_start(); ?>
<?php require 'dashboard_header.php'; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="row">
            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h4>Edit Your Profile</h4>
                    </div>
                    <div class="card-body">
                        <form action="profile_update.php" method="POST">
                            <div class="mb-3">
                                <label for="" class="form-label">Name</label>
                                <input type="text" name="name" class="form-control" value="<?= $after_assoc_user_info['Name'] ?>">
                            </div>
                            <input type="hidden" name="user_id" value="<?= $after_assoc_user_info['Id'] ?>">
                            <div class="mb-3">
                                <label for="" class="form-label">Password</label>
                                <input type="password" name="password" class="form-control">
                            </div>
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card h-auto">
                    <div class="card-header">
                        <h4>Update Your Image</h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($_SESSION["photo_up"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["photo_up"]; ?></div>
                        <?php } unset($_SESSION["photo_up"]) ?>
                        <form action="image_update.php" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="">Image</label>
                                <input type="file" class="form-control" name="image" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">

                                <?php if(isset($_SESSION['extention'])){ ?>
                                    <strong class="text-danger"><?= $_SESSION["extention"]; ?></strong>
                                <?php } unset($_SESSION['extention']) ?>

                                <div class="mt-3"><img src="" width="100" id="blah" alt=""></div>
                            </div>
                            <button type="submit" class="btn btn-primary">Update Image</button>
                        </form>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>
<!--**********************************
            Content body end
***********************************-->

<?php require 'dashboard_footer.php'; ?>


<?php if(isset($_SESSION['update'])){ ?>
    <script>
        Swal.fire(
            'Good job!',
            '<?= $_SESSION['update'] ?>',
            'success'
        )
    </script>
<?php } unset($_SESSION['update']) ?>
