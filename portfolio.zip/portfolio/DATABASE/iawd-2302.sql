-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 14, 2023 at 06:01 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iawd-2302`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` int NOT NULL,
  `designation` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `short_description` text NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `designation`, `name`, `nickname`, `short_description`, `image`) VALUES
(1, 'Web Developer', 'Developer Tusar', 'Imran', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 'image.png');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `message`) VALUES
(4, 'Blair Langley', 'sepa@mailinator.com', 'Qui est modi hic dol', 'Non voluptas aut hic'),
(5, 'Rhona Mosley', 'hiheb@mailinator.com', 'Velit velit culpa e', 'In ut aliquid nesciu'),
(6, 'Lila Garcia', 'bumim@mailinator.com', 'Doloribus non ea aut', 'Quos adipisci eaque '),
(7, 'Keaton Lowery', 'godecupe@mailinator.com', 'Facere voluptate con', 'Sed explicabo Volup'),
(9, 'Benedict Mcintosh', 'mory@mailinator.com', 'Et harum consequatur', 'Eum libero consectet');

-- --------------------------------------------------------

--
-- Table structure for table `expertises`
--

CREATE TABLE `expertises` (
  `id` int NOT NULL,
  `topic_name` varchar(50) NOT NULL,
  `percentage` int NOT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `expertises`
--

INSERT INTO `expertises` (`id`, `topic_name`, `percentage`, `status`) VALUES
(4, 'Html', 95, 1),
(5, 'CSS', 90, 1),
(6, 'Bootstrap', 85, 1),
(7, 'WordPress', 85, 1),
(8, 'PHP', 60, 1),
(9, 'Laravel', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `logos`
--

CREATE TABLE `logos` (
  `id` int NOT NULL,
  `header_logo` varchar(50) DEFAULT NULL,
  `footer_logo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `logos`
--

INSERT INTO `logos` (`id`, `header_logo`, `footer_logo`) VALUES
(1, 'header_logo.png', 'footer_logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `portfolios`
--

CREATE TABLE `portfolios` (
  `id` int NOT NULL,
  `title` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `portfolios`
--

INSERT INTO `portfolios` (`id`, `title`, `category`, `image`, `status`) VALUES
(2, 'Web Development', 'PHP & Laravel', 'portfolio-176035.jpg', 1),
(3, 'Graphic Design', 'LOGO', 'portfolio-104637.jpg', 1),
(4, 'Digital Marketing', 'SEO', 'portfolio-161315.jpg', 1),
(5, 'Video Editing', 'Shot Video', 'portfolio-196234.jpg', 1),
(6, '3D Animation', 'Animation', 'portfolio-148925.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int NOT NULL,
  `title` varchar(50) NOT NULL,
  `short_description` text NOT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `short_description`, `status`) VALUES
(5, 'Web Development', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 1),
(6, 'Graphic Design', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 1),
(7, 'Digital Marketing', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 1),
(8, '3D Animation', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 1),
(9, 'Video Editing', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 1),
(11, 'WordPress', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `occupation`, `image`, `description`, `status`) VALUES
(3, 'Md Tusar Imran', 'Web Developer', 'testimonial-165794.png', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 1),
(4, 'Aspen Giles', 'Graphic Designer', 'testimonial-148250.jpg', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 1),
(5, 'Nichole Simmons', 'Digital Marketer', 'testimonial-136270.jpg', 'A web developer makes and maintains websites. They are in charge of a site’s overall look and feel. Web developers also handle the technical aspects of a website.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Id` int NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Number` varchar(20) NOT NULL,
  `Password` varchar(70) NOT NULL,
  `Gender` varchar(15) NOT NULL,
  `Image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Id`, `Name`, `Email`, `Number`, `Password`, `Gender`, `Image`) VALUES
(6, 'Md Tusar Imran', 'mdtusarimran05@gmail.com', '01772795704', '$2y$10$.wpDHWQCKrs5qkoSkIvpi.UozegS/9puBu2pq1zi/iXV0/JqC74xq', 'Male', '6.png'),
(7, 'Brandon Love', 'vegasyv@mailinator.com', '63832165498', '$2y$10$FS.QQjoO.ubBcPMHoOH2Uu06uz40N49NC4qEYyS7ZU8IKWhVDzskG', 'Male', NULL),
(8, 'Tanya Mcknight', 'badifufup@mailinator.com', '63832165498342', '$2y$10$r.whAhtx1Jbp4ouIUMQ/pORUFOHfxwAmxH3LwzqHYiBAKO8gMmTIq', 'Male', NULL),
(9, 'Lesley Tyson', 'bubycuzeh@mailinator.com', '28063832165498', '$2y$10$/xL7X9S.aFgOv3XmONdhgeT1xh4S5JOHOi3np0hgRb8roBibOxOUi', 'Male', NULL),
(10, 'Harrison Stevenson', 'fisivyvela@mailinator.com', '81963832165498', '$2y$10$CYD4/uSi/KizM5NVkkzYa.xsP1A0gPLO.yF0L8PtuRSP6IkxEWW.2', 'Male', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expertises`
--
ALTER TABLE `expertises`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logos`
--
ALTER TABLE `logos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolios`
--
ALTER TABLE `portfolios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `expertises`
--
ALTER TABLE `expertises`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `logos`
--
ALTER TABLE `logos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `portfolios`
--
ALTER TABLE `portfolios`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `Id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
