<?php
    session_start();
    require 'db_connect.php';

    $expertise = "SELECT * FROM expertises";
    $expertise_res = mysqli_query($db_connection, $expertise);
?>

<?php require 'dashboard_header.php'; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="row">
            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        <h4>Expertise List</h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($_SESSION["delete_expertise"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["delete_expertise"]; ?></div>
                        <?php } unset($_SESSION["delete_expertise"]) ?>
                        <table class="table table-bordered">
                            <tr>
                                <th>SL</th>
                                <th>Topic_Name</th>
                                <th>Percentage</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php foreach($expertise_res as $sl => $skill){ ?>
                                <tr>
                                    <td><?= $sl + 1 ?></td>
                                    <td><?= $skill['topic_name'] ?></td>
                                    <td><?= $skill['percentage'] ?>%</td>
                                    <td>
                                        <a href="status_change.php?id=<?= $skill['id'] ?>" class="btn btn-sm btn-<?= $skill['status'] == 1? 'success' : 'light' ?>"><?= $skill['status'] == 1? 'Active' : 'Deactive' ?></a>
                                    </td>
                                    <td>
                                        <div class="d-flex">
	                                        <a href="delete_expertise.php?id=<?= $skill['id'] ?>" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php }?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card h-auto">
                    <div class="card-header">
                        <h4>Add Expertise</h4>
                    </div>
                    <div class="card-body">

                        <?php if(isset($_SESSION["expertise"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["expertise"]; ?></div>
                        <?php } unset($_SESSION["expertise"]) ?>

                        <form action="expertise_post.php" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="topic_name">Topic Name</label>
                                <input type="text" name="topic_name" class="form-control" id="topic_name">
                            </div>
                            <div class="mb-3">
                                <label for="percentage">Percentage</label>
                                <input type="number" name="percentage" class="form-control" id="percentage">
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Add Expertise</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>
<!--**********************************
            Content body end
***********************************-->

<?php require 'dashboard_footer.php'; ?>

