<?php 
    session_start();
    require 'db_connect.php';
    $id = $_GET['id'];

    $image = "SELECT * FROM portfolios WHERE id=$id";
    $image_res = mysqli_query($db_connection, $image);
    $after_assoc = mysqli_fetch_assoc($image_res);
    $delete_from = 'uploads/portfolio/'.$after_assoc['image'];
    unlink($delete_from);
    
    $delete = "DELETE FROM portfolios WHERE id=$id";
    mysqli_query($db_connection, $delete);
    $_SESSION['delete_portfolio'] = 'Portfolio Deleted Successfully!';
    header('location:portfolio.php');
    

?>