<?php
    session_start();
    require 'db_connect.php';
    $select = "SELECT * FROM users";
    $select_result = mysqli_query($db_connection, $select);

    $total = "SELECT COUNT(*) as total FROM users";
    $total_user = mysqli_query($db_connection, $total);
    $after_assoc_total = mysqli_fetch_assoc($total_user);
?>

<?php require 'dashboard_header.php'; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="row">
            <div class="col m-auto">
                <div class="card">
                    <div class="card-header">
                        <h4>Users List</h4>
                        <p>Total Users: <?= $after_assoc_total['total'] ?></p>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Number</th>
                                <th>Gender</th>
                                <th>Action</th>
                            </tr>
                            <?php foreach($select_result as $key =>$user ){ ?>
                                <tr>
                                    <td><?= $key+1 ?></td>
                                    <td><?= $user['Name'] ?></td>
                                    <td><?= $user['Email'] ?></td>
                                    <td><?= $user['Number'] ?></td>
                                    <td><?= $user['Gender'] ?></td>
                                    <td>
                                        <div class="d-flex">
	                                        <a data-link="user_delete.php?id=<?= $user['Id'] ?>" class="btn btn-danger shadow btn-xs sharp delete"><i class="fa fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>
<!--**********************************
            Content body end
***********************************-->

<?php require 'dashboard_footer.php'; ?>
<script>
    $('.delete').click(function(){
        var link = $(this).attr('data-link');
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = link;
            }
        })

    })
</script>
<?php if(isset($_SESSION['userDelete'])){ ?>
    <script>
        Swal.fire(
            'Deleted!',
            'Your User has been deleted.',
            'success'
        )
    </script>
<?php }unset($_SESSION['userDelete']) ;?>