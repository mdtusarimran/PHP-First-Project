<?php 
    session_start();
    require 'db_connect.php';

    $topic_name = $_POST['topic_name'];
    $percentage = $_POST['percentage'];

    $insert = "INSERT INTO expertises(topic_name, percentage)VALUES('$topic_name', '$percentage')";
    mysqli_query($db_connection, $insert);

    $_SESSION['expertise'] = 'New Expertise Added!';
    header('location:expertise.php');


?>