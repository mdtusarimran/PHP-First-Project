<?php
    session_start();
    require 'db_connect.php';

    $service = "SELECT * FROM services";
    $service_res = mysqli_query($db_connection, $service);
?>

<?php require 'dashboard_header.php'; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="row">
            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        <h4>Expertise List</h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($_SESSION["delete_service"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["delete_service"]; ?></div>
                        <?php } unset($_SESSION["delete_service"]) ?>

                        <table class="table table-bordered">
                            <tr>
                                <th>SL</th>
                                <th>Title</th>
                                <th>Short Description</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php foreach($service_res as $sl => $service){ ?>
                                <tr>
                                    <td><?= $sl + 1 ?></td>
                                    <td><?= $service['title'] ?></td>
                                    <td><?= $service['short_description'] ?></td>
                                    <td>
                                        <a href="service_status_change.php?id=<?= $service['id'] ?>" class="btn btn-sm btn-<?= $service['status'] == 1? 'success' : 'light' ?>"><?= $service['status'] == 1? 'Active' : 'Deactive' ?></a>
                                    </td>
                                    <td>
                                        <div class="d-flex">
	                                        <a href="delete_service.php?id=<?= $service['id'] ?>" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php }?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card h-auto">
                    <div class="card-header">
                        <h4>Add Service</h4>
                    </div>
                    <div class="card-body">

                        <?php if(isset($_SESSION["service"])){ ?>
                            <div class="alert alert-success"><?= $_SESSION["service"]; ?></div>
                        <?php } unset($_SESSION["service"]) ?>

                        <form action="service_post.php" method="POST">
                            <div class="mb-3">
                                <label for="title">Title</label>
                                <input type="text" name="title" class="form-control" id="title">
                            </div>
                            <div class="mb-3">
                                <label for="short_description">Short Description</label>
                                <textarea class="form-control" name="short_description" id="short_description" cols="20" rows="5"></textarea>
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Add Service</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>
<!--**********************************
            Content body end
***********************************-->

<?php require 'dashboard_footer.php'; ?>

