<?php
    session_start();
    require'db_connect.php';

    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    $flag = false;

    if(!$name){
        $flag = true;
        $_SESSION['name'] = 'Enter Your Name !';
    }
    if(!$email){
        $flag = true;
        $_SESSION['email'] = 'Enter Your Email !';
    }else{
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $flag = true;
            $_SESSION['email'] = "Enter Valid Email('@' missing)!";
        }
    }
    if(!$subject){
        $flag = true;
        $_SESSION['subject'] = 'Enter Subject !';
    }
    if(!$message){
        $flag = true;
        $_SESSION['message'] = 'Enter Your Message !';
    }

    if($flag){
        header('location:index.php');
    }else{

        $insert = "INSERT INTO contacts(name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";
        mysqli_query($db_connection, $insert);

        $_SESSION['success'] = 'Your Message Sent Successfully !';

        header('location:index.php');

    }

?>