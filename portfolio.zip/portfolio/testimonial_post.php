<?php 
    session_start();
    require 'db_connect.php';

    $name = $_POST['name'];
    $occupation = $_POST['occupation'];
    $description = $_POST['description'];
    $image = $_FILES['image'];

    $after_explode = explode('.', $image['name']);
    $extension = end($after_explode);
    $file_name = 'testimonial'.'-'.rand(100000,200000).'.'.$extension;
    
    $new_location = 'uploads/testimonial/'.$file_name;
    move_uploaded_file($image['tmp_name'], $new_location);
    

    $insert = "INSERT INTO testimonials(name, occupation, description, image)VALUES('$name', '$occupation', '$description', '$file_name')";
    mysqli_query($db_connection, $insert);

    $_SESSION['testimonial'] = 'New Testimonial Added!';
    header('location:testimonial.php');


?>