<?php
    session_start();
    require 'db_connect.php';

    $id = $_SESSION['user_id'];
    $image = $_FILES['image'];
    
    $after_explode = explode('.', $image['name']);
    $extension = end($after_explode);
    $allowed_extension = ['jpg', 'png', 'jpeg'];
    $user = "SELECT * FROM users WHERE Id=$id";
    $user_res = mysqli_query($db_connection, $user);
    $after_assoc = mysqli_fetch_assoc($user_res);

    if($after_assoc['Image'] == null){
        if(in_array($extension, $allowed_extension)){

            if($image['size'] <= 512000){
                $file_name = $id.'.'.$extension;
                $new_location = 'uploads/users_img/'.$file_name;
                move_uploaded_file($image['tmp_name'], $new_location);
    
                $update = "UPDATE users SET Image='$file_name' WHERE Id=$id";
                mysqli_query($db_connection, $update);
                $_SESSION['photo_up'] = 'Profile Image Update Successfully!';
                header('location:profile.php');
                
    
            }else{
                $_SESSION['extention'] = 'Maximum Image Size 512kb';
                header('location:profile.php');
            }
    
        }else{
            $_SESSION['extention'] = 'jpg, png or jpeg extention not found!';
            header('location:profile.php');
        }
    }
    else{


        if(in_array($extension, $allowed_extension)){

            if($image['size'] <= 512000){

                $delete_from = 'uploads/users_img/'. $after_assoc['Image'];
                unlink($delete_from);
                
                $file_name = $id.'.'.$extension;
                $new_location = 'uploads/users_img/'.$file_name;
                move_uploaded_file($image['tmp_name'], $new_location);
    
                $update = "UPDATE users SET Image='$file_name' WHERE Id=$id";
                mysqli_query($db_connection, $update);
                $_SESSION['photo_up'] = 'Profile Image Update Successfully!';
                header('location:profile.php');
                
    
            }else{
                $_SESSION['extention'] = 'Maximum Image Size 512kb';
                header('location:profile.php');
            }
    
        }else{
            $_SESSION['extention'] = 'jpg or png extention not found!';
            header('location:profile.php');
        }

    }

    

?>