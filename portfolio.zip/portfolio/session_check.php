<?php 

    if(!isset($_SESSION['login hoise'])){
        header('location:login.php');
    }

?>