<?php 
    session_start();
    require 'db_connect.php';
    $id = $_GET['id'];

    $image = "SELECT * FROM testimonials WHERE id=$id";
    $image_res = mysqli_query($db_connection, $image);
    $after_assoc = mysqli_fetch_assoc($image_res);
    $delete_from = 'uploads/testimonial/'.$after_assoc['image'];
    unlink($delete_from);
    
    $delete = "DELETE FROM testimonials WHERE id=$id";
    mysqli_query($db_connection, $delete);
    $_SESSION['delete_testimonial'] = 'testimonial Deleted Successfully!';
    header('location:testimonial.php');
    

?>